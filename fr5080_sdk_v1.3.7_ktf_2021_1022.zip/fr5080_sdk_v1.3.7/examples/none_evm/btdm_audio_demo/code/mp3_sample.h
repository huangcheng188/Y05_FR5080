#ifndef _MP3_SAMPLE_H
#define _MP3_SAMPLE_H

#include <stdint.h>

extern const uint8_t mp3_sample[];

uint32_t mp3_sample_get_size(void);

#endif  // _MP3_SAMPLE_H
